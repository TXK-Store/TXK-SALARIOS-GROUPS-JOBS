local VorpCore = exports.vorp_core:GetCore()

-- Função para verificar se o trabalho ou grupo do jogador é permitido para receber o pagamento
local function isPlayerAllowed(source)
    local user = VorpCore.getUser(source)
    local character = user.getUsedCharacter
    
    local job = character.job -- Obtém o trabalho do jogador
    local group = character.group -- Obtém o grupo do jogador

    -- Verifica se o trabalho ou grupo do jogador está configurado para receber salário
    return Config.Jobs[job] ~= nil or Config.Groups[group] ~= nil
end

-- Função para pagar o salário aos jogadores permitidos
Citizen.CreateThread(function()
    while true do
        local players = GetPlayers()
        
        for _, playerId in ipairs(players) do
            if isPlayerAllowed(playerId) then -- Apenas jogadores permitidos recebem o pagamento
                local user = VorpCore.getUser(playerId)
                local character = user.getUsedCharacter
                local job = character.job
                local group = character.group

                -- Determina o salário com base no trabalho ou grupo
                local salary = Config.Jobs[job] or Config.Groups[group]

                -- Adiciona o salário ao jogador
                if salary then
                    character.addCurrency(0, salary) -- Adiciona o salário em dinheiro
                    TriggerClientEvent('vorp:NotifyLeft', playerId, "Pagamento", "~q~Salário de $ "..salary, "INVENTORY_ITEMS", "money_moneystack", 3000, "COLOR_GREEN")
                end
            end
        end
        
        -- Espera o intervalo definido em Config.PaymentInterval antes de fazer o próximo pagamento
        Citizen.Wait(Config.PaymentInterval * 1000)
    end
end)
