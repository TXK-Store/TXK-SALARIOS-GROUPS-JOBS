Config = {}

-- Configuração de salários para cada trabalho, onde o nome do trabalho já define que ele é permitido
Config.Jobs = {
    -- JOBS = SALARIO DO JOB 
    ["police"] = 8,
    ["doctor"] = 6,
    ["farmer"] = 4,
}

-- Configuração de salários para cada grupo, onde o nome do grupo já define que ele é permitido
Config.Groups = {
    -- Grupos de Administração
    ["admin"] = 1,
    ["moderator"] = 1,
    
    -- Grupos VIPs e seus salários
    ["vip_bronze"] = 1.5,
    ["vip_prata"] = 2,
    ["vip_ouro"] = 3,
    ["vip_diamante"] = 4,
}


-- Intervalo global de pagamento em segundos (exemplo: 1 hora = 3600 segundos),(exemplo: 30 minutos = 1800 segundos)
Config.PaymentInterval = 30