fx_version 'adamant'
games { 'rdr3' }

rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

author 'TXK STORE'
description 'Script de salario de trabalhos e grupos para monetizar seu servidor'
version '1.0.0'
lua54 'yes'

server_scripts { 
'config.lua',
'server/server.lua'   -- Script do servidor
}